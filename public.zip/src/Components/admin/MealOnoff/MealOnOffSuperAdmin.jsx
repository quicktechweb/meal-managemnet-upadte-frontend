import { useEffect, useState } from "react";
import axios from "axios";

const MEAL_COLORS = {
  Breakfast: { bg: "#FAC775", text: "#633806" },
  Lunch: { bg: "#85B7EB", text: "#042C53" },
  Dinner: { bg: "#9FE1CB", text: "#04342C" },
};

export default function MealOnOffSuperAdmin() {
  const [allData, setAllData] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [institutes, setInstitutes] = useState([]);
  const [days, setDays] = useState([]);
  const [instFilter, setInstFilter] = useState("all");
  const [dayFilter, setDayFilter] = useState("all");
  const [toast, setToast] = useState("");

  useEffect(() => {
    fetchMeals();
  }, []);

  useEffect(() => {
    applyFilter();
  }, [allData, instFilter, dayFilter]);

  const fetchMeals = async () => {
    const res = await axios.get("https://meal-management-backend-update-3.onrender.com/api/allwise-institute-user-meal-order-admin", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    const data = res.data.data;
    setAllData(data);
    setInstitutes([...new Map(data.map((d) => [d.institute_id, d.institute_name || d.institute_id])).entries()]);
    setDays([...new Set(data.flatMap((d) => d.meals.map((m) => m.day)))]);
  };

  const applyFilter = () => {
    setFiltered(
      allData
        .filter((d) => instFilter === "all" || d.institute_id === instFilter)
        .map((d) => ({
          ...d,
          meals: dayFilter === "all" ? d.meals : d.meals.filter((m) => m.day === dayFilter),
        }))
        .filter((d) => d.meals.length > 0)
    );
  };

  const toggleMeal = async (docId, mealId, newVal) => {
    try {
      await axios.patch(
        `https://meal-management-backend-update-3.onrender.com/api/superadmin/meal-toggle/${docId}/${mealId}`,
        { is_on: newVal },
        { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
      );

      setAllData((prev) =>
        prev.map((d) =>
          d._id === docId
            ? { ...d, meals: d.meals.map((m) => (m._id === mealId ? { ...m, is_on: newVal } : m)) }
            : d
        )
      );
      showToast(`Meal turned ${newVal ? "on" : "off"}`);
    } catch {
      showToast("Failed to update meal");
    }
  };

  const toggleAll = async (docId, val) => {
    const doc = allData.find((d) => d._id === docId);
    if (!doc) return;
    for (const meal of doc.meals) {
      await toggleMeal(docId, meal._id, val);
    }
  };

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2500);
  };

  const totalMeals = filtered.reduce((a, d) => a + d.meals.length, 0);
  const onMeals = filtered.reduce((a, d) => a + d.meals.filter((m) => m.is_on).length, 0);

  return (
    <div className="p-4">
      {/* Header + Filters */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
        <div>
          <h2 className="text-lg font-medium">Meal management</h2>
          <p className="text-sm text-gray-500">Institute-wise meal on/off control</p>
        </div>
        <div className="flex gap-2">
          <select value={instFilter} onChange={(e) => setInstFilter(e.target.value)} className="border rounded px-3 py-1 text-sm">
            <option value="all">All institutes</option>
            {institutes.map(([id, name]) => <option key={id} value={id}>{name}</option>)}
          </select>
          <select value={dayFilter} onChange={(e) => setDayFilter(e.target.value)} className="border rounded px-3 py-1 text-sm">
            <option value="all">All days</option>
            {days.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 mb-4">
        {[
          { label: "Total meals", value: totalMeals, color: "text-gray-800" },
          { label: "Meal on", value: onMeals, color: "text-green-700" },
          { label: "Meal off", value: totalMeals - onMeals, color: "text-red-600" },
          { label: "Users", value: new Set(filtered.map((d) => d.user_id._id)).size, color: "text-gray-800" },
        ].map((s) => (
          <div key={s.label} className="bg-gray-50 rounded-lg p-3 text-center">
            <p className="text-xs text-gray-500">{s.label}</p>
            <p className={`text-2xl font-medium ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Institute Cards */}
      {filtered.map((doc) => {
        const name = doc.user_id.information?.full_name || "Unknown";
        const initials = name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2);
        return (
          <div key={doc._id} className="border rounded-xl p-4 mb-3 bg-white">
            <div className="flex items-center gap-3 mb-3 flex-wrap">
              <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-800 flex items-center justify-content-center text-sm font-medium">
                {initials}
              </div>
              <div className="flex-1">
                <p className="font-medium text-sm">{name}</p>
                <p className="text-xs text-gray-500">{doc.institute_name || doc.institute_id} · UID {doc.user_id.uid}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => toggleAll(doc._id, true)} className="text-xs px-3 py-1 border rounded">All on</button>
                <button onClick={() => toggleAll(doc._id, false)} className="text-xs px-3 py-1 border rounded">All off</button>
              </div>
            </div>

            {doc.meals.map((m) => (
              <div key={m._id} className="flex items-center justify-between py-2 border-t">
                <div className="flex items-center gap-3">
                  <span className="text-xs px-2 py-1 rounded font-medium" style={{ background: MEAL_COLORS[m.meal_type]?.bg, color: MEAL_COLORS[m.meal_type]?.text }}>
                    {m.meal_type}
                  </span>
                  <div>
                    <p className="text-sm">{m.day}</p>
                    <p className="text-xs text-gray-400">{m.selected_items.map((i) => i.title).join(", ")} · ৳{m.package_price}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs ${m.is_on ? "text-green-700" : "text-gray-400"}`}>{m.is_on ? "On" : "Off"}</span>
                  <button
                    onClick={() => toggleMeal(doc._id, m._id, !m.is_on)}
                    className={`w-11 h-6 rounded-full relative transition-colors ${m.is_on ? "bg-green-500" : "bg-gray-300"}`}
                  >
                    <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${m.is_on ? "translate-x-5" : ""}`} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        );
      })}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 bg-white border rounded-lg px-4 py-2 text-sm shadow">
          {toast}
        </div>
      )}
    </div>
  );
}