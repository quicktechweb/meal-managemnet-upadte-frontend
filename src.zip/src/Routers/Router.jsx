import { createBrowserRouter } from "react-router-dom";
import Main from "../Layout/Main";
import Home from "../Pages/FrontEnd/Home/Home/Home";
import Layouts from "../Layouts";
import ErrorPage from "../Shared/ErrorPage/ErrorPage/ErrorPage";


const router = createBrowserRouter([


 {
    path: "/",
    element: <Layouts />,
    errorElement: (
      <>
       <ErrorPage/>
      </>
    ),
    children: [
      
      
      {
    path: "/main",
    element: <Main />,
  },
  {
    path: "/",
    element: <Home />,
  },
  
 

  
 
  
  
  
  
  
 
   
    
     
     
     

        ],
      },

]);

export default router;
