import React, { useEffect, useMemo, useState,useRef  } from "react";
import { useForm, Controller, FormProvider } from "react-hook-form";
import { IoMdEye, IoMdEyeOff } from "react-icons/io";
import { Link, useNavigate } from "react-router-dom";
import CustomSelect from "../CustomSelect";
import DynamicDropdown from "../DynamicSelect";
import DocumentUpload from "../DocumentUpload";
import { useInstituteUserRegistration } from "../../api/auth/auth.hook";
import { useAllLocation, useApprovedInstituteUser } from "../../api/cms/user.hook";
import toast from "react-hot-toast";

const InputField = ({ label, name, control, type = "text", rules = {} }) => (
  <Controller
    name={name}
    control={control}
    rules={rules}
    render={({ field, fieldState }) => (
      <>
        <div className="relative">
          <input
            {...field}
            type={type}
            placeholder=" "
            className={`peer w-full text-[13px] border rounded-md px-3 h-[50px] text-sm focus:outline-none text-gray-500 focus:border-gray-300 transition-all ${
              fieldState.error ? "border-red-500" : "border-gray-200"
            }`}
          />
          <label className="absolute left-3 bg-white px-1 text-gray-500 transition-all top-1/2 -translate-y-1/2 text-sm md:text-base peer-focus:top-1 peer-focus:text-xs peer-focus:text-black peer-not-placeholder-shown:top-1 peer-not-placeholder-shown:text-xs pointer-events-none">
            {label}
          </label>
        </div>
        {fieldState.error && (
          <span className="text-red-500 text-sm">{fieldState.error.message}</span>
        )}
      </>
    )}
  />
);


// SearchableSelect component — file এর top এ বা আলাদা file এ রাখো
const SearchableSelect = ({
  field,
  options = [],
  placeholder = "Select...",
  disabled = false,
  onChange,
}) => {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const filtered = options.filter((opt) =>
    opt?.toLowerCase().includes(search.toLowerCase())
  );

  const selectedLabel = field.value
    ? options.find((o) => o === field.value) || field.value
    : "";

  // outside click এ close
  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative w-full">
      {/* Trigger button */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => !disabled && setOpen((prev) => !prev)}
        className="w-full border border-gray-200 rounded-md px-3 h-[50px] text-base text-gray-500 text-left flex items-center justify-between disabled:opacity-50 disabled:cursor-not-allowed bg-white"
      >
        <span className={selectedLabel ? "text-gray-700" : "text-gray-400"}>
          {selectedLabel || placeholder}
        </span>
        <span className="text-gray-400">{open ? "▲" : "▼"}</span>
      </button>

      {/* Dropdown */}
      {open && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg">
          {/* Search input */}
          <div className="p-2 border-b border-gray-100">
            <input
              type="text"
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:border-gray-400"
            />
          </div>

          {/* Options list */}
          <ul className="max-h-48 overflow-y-auto">
            <li
              onClick={() => {
                onChange ? onChange("") : field.onChange("");
                setOpen(false);
                setSearch("");
              }}
              className="px-3 py-2 text-sm text-gray-400 hover:bg-gray-50 cursor-pointer"
            >
              {placeholder}
            </li>
            {filtered.length > 0 ? (
              filtered.map((opt, idx) => (
                <li
                  key={idx}
                  onClick={() => {
                    onChange ? onChange(opt) : field.onChange(opt);
                    setOpen(false);
                    setSearch("");
                  }}
                  className={`px-3 py-2 text-sm cursor-pointer hover:bg-gray-50 ${
                    field.value === opt ? "bg-gray-100 font-medium text-black" : "text-gray-700"
                  }`}
                >
                  {opt}
                </li>
              ))
            ) : (
              <li className="px-3 py-2 text-sm text-gray-400">No results found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

const UserForm = () => {
  const navigate = useNavigate();
  const [formUploadData, setFormUploadData] = useState([]);

  const { data: location } = useAllLocation();

  const { handleSubmit, control, watch, setValue } = useForm();

  const selectedCountry = watch("country");
  const selectedState = watch("state");
  const selectedDivision = watch("division");
  const selectedDistrict = watch("district");
  const selectedUpazila = watch("upazila");

  const districts = location?.find((loc) => loc.name === selectedDivision);
  const upazila = districts?.districts?.find((upa) => upa?.name === selectedDistrict);
  const uploadedDocs = watch("documents") || [];

  const [passwordShow, setPasswordShow] = useState(false);
  const [confirmPasswordShow, setConfirmPasswordShow] = useState(false);
  const passwordValue = watch("password");

  const [gender, setGender] = useState("");
  const [religion, setReligion] = useState("");

  const [genderOptions, setGenderOptions] = useState(["Male", "Female"]);
  const [gurdianOptions, setGurdianOptions] = useState(["father", "mother", "brother", "sister"]);
  const [religionOptions, setReligionOptions] = useState(["Islam", "Hindu"]);

  const handleCreateGurdian = (newItem) => setGurdianOptions((prev) => [...prev, newItem]);
  const handleCreateGender = (newItem) => setGenderOptions((prev) => [...prev, newItem]);
  const handleCreateReligion = (newItem) => setReligionOptions((prev) => [...prev, newItem]);

  // ✅ StepOne এর মতো organization/institute states
  const [organizeOptions, setOrganizeOptions] = useState(["Company", "Institute"]);
  const [instituteOptionsState, setInstituteOptionsState] = useState({
    Company: ["Office", "Startup", "Agency"],
    Institute: ["School", "College", "University"],
  });

  const organizationType = watch("organization_type");
  const instituteLabel = organizationType ? `${organizationType} Type` : "Type";

  const instituteOptions = useMemo(() => {
    return instituteOptionsState[organizationType] || [];
  }, [organizationType, instituteOptionsState]);

  useEffect(() => {
    setValue("institute_type", "");
  }, [organizationType, setValue]);

  const handleCreateOrganizeType = (value) => {
    setOrganizeOptions((prev) => [...prev, value]);
    setInstituteOptionsState((prev) => ({ ...prev, [value]: [] }));
  };

  const handleCreateInstituteType = (value) => {
    if (!organizationType) return;
    setInstituteOptionsState((prev) => ({
      ...prev,
      [organizationType]: [...(prev[organizationType] || []), value],
    }));
  };

  const { data } = useApprovedInstituteUser();

  const selectedOrgType = watch("organization_type");
  const selectedInstituteType = watch("institute_type");

  const uniqueOrgTypes = [
    ...new Set(data?.map((d) => d.organization_type).filter(Boolean)),
  ];

  const filteredInstituteTypes = [
    ...new Set(
      data
        ?.filter((d) => d.organization_type === selectedOrgType)
        .map((d) => d.instituteType)
        .filter(Boolean),
    ),
  ];

  const filteredInstitutes = data?.filter(
    (d) =>
      d.organization_type === selectedOrgType &&
      d.instituteType === selectedInstituteType,
  );

  const { mutateAsync, isPending } = useInstituteUserRegistration();

  const onSubmit = async (data) => {
    data.room_number = Number(data.room_number);
    await mutateAsync(
      { name_of_institute: filteredInstitutes?.name_of_institute, ...data },
      {
        onSuccess: (data) => {
          if (data) {
            toast.success(data?.message);
            navigate("/auth/login");
          }
        },
        onError: (err) => {
          toast.error(err?.response?.data?.message);
        },
      },
    );
  };


  // ১. institute_id select করলে selected institute object বের করো
const selectedInstituteId = watch("institute_id");
const selectedHall = watch("hall");

const selectedInstituteObj = filteredInstitutes?.find(
  (inst) => inst._id === selectedInstituteId
);

// ২. selected institute এর halls বের করো
// data structure অনুযায়ী: name_of_hall string হলে array বানাও,
// অথবা যদি halls array থাকে সেটা use করো
const hallOptions = selectedInstituteObj
  ? Array.isArray(selectedInstituteObj.name_of_hall)
    ? selectedInstituteObj.name_of_hall
    : selectedInstituteObj.name_of_hall
    ? [selectedInstituteObj.name_of_hall]
    : []
  : [];

// ৩. selected hall এর messes বের করো
const messOptions = selectedInstituteObj
  ? Array.isArray(selectedInstituteObj.name_of_mess)
    ? selectedInstituteObj.name_of_mess
    : selectedInstituteObj.name_of_mess
    ? [selectedInstituteObj.name_of_mess]
    : []
  : [];

  return (
    <>
      <FormProvider {...{ handleSubmit, control, watch }}>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">

          <InputField
            label="Full name"
            name="full_name"
            control={control}
            rules={{ required: "Full Name is required" }}
          />
          <InputField
            label="Nick name"
            name="nick_name"
            control={control}
            rules={{}}
          />

          {/* ✅ StepOne এর মতো Organization & Institute block */}
          {/* <div className="bg-gray-100 p-3 rounded-2xl flex flex-col gap-2">
            <Controller
              name="organization_type"
              control={control}
              rules={{ required: "This field is required" }}
              render={({ field: { onChange, value }, fieldState: { error } }) => (
                <div className="space-y-1">
                  <CustomSelect
                    label="Organization Type"
                    options={organizeOptions}
                    value={value ?? ""}
                    onChange={(newValue) => onChange(newValue)}
                    onCreate={handleCreateOrganizeType}
                    allowCreate
                  />
                  {error && <p className="text-red-500 text-sm">{error.message}</p>}
                </div>
              )}
            />

            <Controller
              name="institute_type"
              control={control}
              rules={{ required: "This field is required" }}
              render={({ field, fieldState: { error } }) => (
                <div className="space-y-1">
                  <label className="text-sm font-medium">
                    {instituteLabel} <span className="text-red-500">*</span>
                  </label>
                  <CustomSelect
                    label={instituteLabel}
                    options={instituteOptions}
                    value={field.value || ""}
                    onChange={field.onChange}
                    onCreate={(newItem) => {
                      handleCreateInstituteType(newItem);
                      field.onChange(newItem);
                    }}
                    allowCreate
                    disabled={!organizationType}
                  />
                  {error && <p className="text-red-500 text-sm">{error.message}</p>}
                </div>
              )}
            />
          </div> */}

          <InputField
            label="Username"
            name="username"
            control={control}
            rules={{ required: "Username required" }}
          />
          <InputField
            label="Father Name"
            name="father_name"
            control={control}
            rules={{ required: "Father name required" }}
          />
          <InputField
            label="Mother Name"
            name="mother_name"
            control={control}
            rules={{ required: "Mother name required" }}
          />
          <InputField
            label="Guardian Name"
            name="guardian_name"
            control={control}
            rules={{ required: "Guardian name required" }}
          />

          <Controller
            name="relation_with_guardian"
            control={control}
            rules={{ required: "Relation with Guardian is required" }}
            render={({ field: { onChange, value }, fieldState: { error } }) => (
              <CustomSelect
                label="Relation with Guardian"
                options={gurdianOptions}
                value={value ?? ""}
                onChange={(newValue) => onChange(newValue)}
                onCreate={handleCreateGurdian}
                allowCreate
                showOther
              />
            )}
          />

          <InputField
            label="Guardian Contact Number"
            name="guardian_number"
            control={control}
            rules={{ required: "Guardian Contact Number required" }}
          />

          <Controller
            name="gender"
            control={control}
            rules={{ required: "Gender is required" }}
            render={({ field: { onChange, value }, fieldState: { error } }) => (
              <div className="space-y-1">
                <label className="block text-sm font-medium text-gray-700">Gender</label>
                <CustomSelect
                  label="Gender"
                  options={genderOptions}
                  value={value ?? ""}
                  onChange={(newValue) => {
                    onChange(newValue);
                    setGender(newValue);
                  }}
                  onCreate={handleCreateGender}
                  allowCreate
                  showOther
                />
                {error && <p className="text-red-500 text-sm mt-1">{error.message}</p>}
              </div>
            )}
          />

          <Controller
            name="religion"
            control={control}
            rules={{ required: "Religion is required" }}
            render={({ field: { onChange, value }, fieldState: { error } }) => (
              <div className="space-y-1">
                <label className="block text-sm font-medium text-gray-700">Religion</label>
                <CustomSelect
                  label="Religion"
                  options={religionOptions}
                  value={value ?? ""}
                  onChange={(newValue) => {
                    onChange(newValue);
                    setReligion(newValue);
                  }}
                  onCreate={handleCreateReligion}
                  allowCreate
                  showOther
                />
                {error && <p className="text-red-500 text-sm mt-1">{error.message}</p>}
              </div>
            )}
          />

          <div className="mt-2">
            <InputField
              label="Date of Birth"
              name="date_of_birth"
              control={control}
              type="date"
              rules={{ required: "Date of Birth required" }}
            />
          </div>

          <DynamicDropdown control={control} />

          <div className="w-full flex flex-col gap-2">
            <h4 className="text-[18px] font-semibold text-gray-500">Address</h4>

            <Controller
              name="country"
              control={control}
              rules={{ required: "Country is required" }}
              render={({ field }) => (
                <select {...field} className="border border-gray-300 px-2 py-3 rounded w-full text-gray-600">
                  <option value="">Select Country</option>
                  <option value="bangladesh">Bangladesh</option>
                </select>
              )}
            />

            {selectedCountry && (
              <Controller
                name="state"
                control={control}
                rules={{ required: "State is required" }}
                render={({ field }) => (
                  <select {...field} className="border border-gray-300 px-2 py-3 rounded w-full text-gray-600">
                    <option value="">Select State</option>
                    <option value="bangladesh">Bangladesh</option>
                  </select>
                )}
              />
            )}

            {selectedState && (
              <Controller
                name="division"
                control={control}
                rules={{ required: "Division is required" }}
                render={({ field }) => (
                  <select {...field} className="border border-gray-300 px-2 py-3 rounded w-full text-gray-600">
                    <option value="">Select Division</option>
                    {location?.map((item) => (
                      <option key={item._id} value={item.name}>{item.name}</option>
                    ))}
                  </select>
                )}
              />
            )}

            {selectedDivision && (
              <Controller
                name="district"
                control={control}
                rules={{ required: "District is required" }}
                render={({ field }) => (
                  <select {...field} className="border border-gray-300 px-2 py-3 rounded w-full text-gray-600">
                    <option value="">Select District</option>
                    {districts?.districts?.map((item) => (
                      <option key={item.name} value={item.name}>{item.name}</option>
                    ))}
                  </select>
                )}
              />
            )}

            {selectedDistrict && (
              <Controller
                name="upazila"
                control={control}
                rules={{ required: "Upazila is required" }}
                render={({ field }) => (
                  <select {...field} className="border border-gray-300 px-2 py-3 rounded w-full text-gray-600">
                    <option value="">Select Upazila</option>
                    {upazila?.upazilas?.map((item) => (
                      <option key={item.name} value={item.name}>{item.name}</option>
                    ))}
                  </select>
                )}
              />
            )}

            {selectedUpazila && (
              <>
                <InputField label="Village" name="village" control={control} />
                <InputField label="Location" name="location" control={control} />
              </>
            )}
          </div>

          <div className="flex flex-col gap-2">
            <h4 className="text-[18px] font-semibold text-gray-500">Contact</h4>
            <InputField
              label="Email"
              name="email"
              type="email"
              control={control}
              rules={{
                required: "Email is required",
                pattern: { value: /\S+@\S+\.\S+/, message: "Invalid email address" },
              }}
            />
            <InputField
              label="Phone Number"
              name="phone"
              control={control}
              rules={{ required: "Phone Number is required" }}
            />
          </div>

          {/* Organization Type — database field */}
        {/* Organization Type */}
<Controller
  name="organization_type"
  control={control}
  rules={{ required: "Organization type is required" }}
  render={({ field, fieldState }) => (
    <>
      <SearchableSelect
        field={field}
        options={uniqueOrgTypes}
        placeholder="Organization Type"
        onChange={(val) => {
          field.onChange(val);
          setValue("institute_type", "");
          setValue("institute_id", "");
          setValue("hall", "");
          setValue("mess", "");
        }}
      />
      {fieldState.error && <span className="text-red-500 text-sm">{fieldState.error.message}</span>}
    </>
  )}
/>

{/* Institute Type */}
<Controller
  name="institute_type"
  control={control}
  rules={{ required: "Institute type is required" }}
  render={({ field, fieldState }) => (
    <>
      <SearchableSelect
        field={field}
        options={filteredInstituteTypes}
        placeholder="Institute Type"
        disabled={!selectedOrgType}
        onChange={(val) => {
          field.onChange(val);
          setValue("institute_id", "");
          setValue("hall", "");
          setValue("mess", "");
        }}
      />
      {fieldState.error && <span className="text-red-500 text-sm">{fieldState.error.message}</span>}
    </>
  )}
/>

{/* Institute Name — label আলাদা তাই custom */}
<Controller
  name="institute_id"
  control={control}
  rules={{ required: "Institute is required" }}
  render={({ field, fieldState }) => {
    const [search, setSearch] = useState("");
    const [open, setOpen] = useState(false);
    const ref = useRef(null);

    const filtered = filteredInstitutes?.filter((inst) =>
      inst.name_of_institute?.toLowerCase().includes(search.toLowerCase())
    );

    const selectedLabel = filteredInstitutes?.find(
      (inst) => inst._id === field.value
    )?.name_of_institute;

    useEffect(() => {
      const handler = (e) => {
        if (ref.current && !ref.current.contains(e.target)) setOpen(false);
      };
      document.addEventListener("mousedown", handler);
      return () => document.removeEventListener("mousedown", handler);
    }, []);

    return (
      <>
        <div ref={ref} className="relative w-full">
          <button
            type="button"
            disabled={!selectedInstituteType}
            onClick={() => selectedInstituteType && setOpen((p) => !p)}
            className="w-full border border-gray-200 rounded-md px-3 h-[50px] text-base text-left flex items-center justify-between disabled:opacity-50 disabled:cursor-not-allowed bg-white text-gray-500"
          >
            <span className={selectedLabel ? "text-gray-700" : "text-gray-400"}>
              {selectedLabel || "Name Of the Institute"}
            </span>
            <span className="text-gray-400">{open ? "▲" : "▼"}</span>
          </button>

          {open && (
            <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg">
              <div className="p-2 border-b border-gray-100">
                <input
                  autoFocus
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search..."
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none"
                />
              </div>
              <ul className="max-h-48 overflow-y-auto">
                {filtered?.length > 0 ? (
                  filtered.map((inst) => (
                    <li
                      key={inst._id}
                      onClick={() => {
                        field.onChange(inst._id);
                        setValue("hall", "");
                        setValue("mess", "");
                        setOpen(false);
                        setSearch("");
                      }}
                      className={`px-3 py-2 text-sm cursor-pointer hover:bg-gray-50 ${
                        field.value === inst._id ? "bg-gray-100 font-medium text-black" : "text-gray-700"
                      }`}
                    >
                      {inst.name_of_institute}
                    </li>
                  ))
                ) : (
                  <li className="px-3 py-2 text-sm text-gray-400">No results found</li>
                )}
              </ul>
            </div>
          )}
        </div>
        {fieldState.error && <span className="text-red-500 text-sm">{fieldState.error.message}</span>}
      </>
    );
  }}
/>

{/* Hall */}
<Controller
  name="hall"
  control={control}
  rules={{ required: "Hall is required" }}
  render={({ field, fieldState }) => (
    <>
      <SearchableSelect
        field={field}
        options={hallOptions}
        placeholder="Name Of the Hall"
        disabled={!selectedInstituteId || hallOptions.length === 0}
        onChange={(val) => {
          field.onChange(val);
          setValue("mess", "");
        }}
      />
      {fieldState.error && <span className="text-red-500 text-sm">{fieldState.error.message}</span>}
    </>
  )}
/>

{/* Mess */}
{selectedHall && (
  <Controller
    name="mess"
    control={control}
    rules={{ required: "Mess is required" }}
    render={({ field, fieldState }) => (
      <>
        <SearchableSelect
          field={field}
          options={messOptions}
          placeholder="Name Of the Mess"
          disabled={messOptions.length === 0}
        />
        {fieldState.error && <span className="text-red-500 text-sm">{fieldState.error.message}</span>}
      </>
    )}
  />
)}

          <InputField
            label="Room Number"
            name="room_number"
            control={control}
            type="number"
            rules={{ required: "Room Number is required", valueAsNumber: true }}
          />

          <div className="flex flex-col gap-1">
            <h4 className="text-[18px] font-semibold text-gray-500">Document</h4>
            <Controller
              name="documents"
              control={control}
              rules={{
                validate: (value) =>
                  (value && value.length > 0) || "At least one document is required",
              }}
              render={({ field: { onChange }, fieldState: { error } }) => (
                <>
                  <DocumentUpload
                    onDocumentsChange={onChange}
                    initialDocuments={uploadedDocs}
                    setFormUploadData={setFormUploadData}
                  />
                  {error && <p className="text-red-500 text-sm mt-1">* {error.message}</p>}
                </>
              )}
            />
          </div>

          {/* PASSWORD FIELD */}
          <Controller
            name="password"
            control={control}
            rules={{ required: "Password is required" }}
            render={({ field, fieldState }) => (
              <>
                <div className="relative">
                  <input
                    {...field}
                    type={passwordShow ? "text" : "password"}
                    placeholder=" "
                    className={`peer w-full border rounded-md px-3 h-[50px] text-base focus:outline-none focus:border-black transition-all ${
                      fieldState.error ? "border-red-500" : "border-gray-200"
                    }`}
                  />
                  <label className="absolute left-3 bg-white px-1 text-gray-500 transition-all top-1/2 -translate-y-1/2 text-sm md:text-base peer-focus:top-1 peer-focus:text-xs peer-focus:text-black peer-not-placeholder-shown:top-1 peer-not-placeholder-shown:text-xs pointer-events-none">
                    Password
                  </label>
                  <div
                    onClick={() => setPasswordShow(!passwordShow)}
                    className="absolute top-1/2 -translate-y-1/2 right-4 text-2xl text-gray-500 cursor-pointer"
                  >
                    {passwordShow ? <IoMdEyeOff /> : <IoMdEye />}
                  </div>
                </div>
                {fieldState.error && (
                  <span className="text-red-500 text-sm">{fieldState.error.message}</span>
                )}
              </>
            )}
          />

          {/* CONFIRM PASSWORD FIELD */}
          <Controller
            name="confirmpassword"
            control={control}
            rules={{
              required: "Confirm password is required",
              validate: (value) => value === passwordValue || "Passwords do not match",
            }}
            render={({ field, fieldState }) => (
              <>
                <div className="relative">
                  <input
                    {...field}
                    type={confirmPasswordShow ? "text" : "password"}
                    placeholder=" "
                    className={`peer w-full border rounded-md px-3 h-[50px] text-base focus:outline-none focus:border-black transition-all ${
                      fieldState.error ? "border-red-500" : "border-gray-200"
                    }`}
                  />
                  <label className="absolute left-3 bg-white px-1 text-gray-500 transition-all top-1/2 -translate-y-1/2 text-sm md:text-base peer-focus:top-1 peer-focus:text-xs peer-focus:text-black peer-not-placeholder-shown:top-1 peer-not-placeholder-shown:text-xs pointer-events-none">
                    Confirm Password
                  </label>
                  <div
                    onClick={() => setConfirmPasswordShow(!confirmPasswordShow)}
                    className="absolute top-1/2 -translate-y-1/2 right-4 text-2xl text-gray-500 cursor-pointer"
                  >
                    {confirmPasswordShow ? <IoMdEyeOff /> : <IoMdEye />}
                  </div>
                </div>
                {fieldState.error && (
                  <span className="text-red-500 text-sm">{fieldState.error.message}</span>
                )}
              </>
            )}
          />

          <div className="flex items-center gap-2">
            <input type="checkbox" />
            <p className="text-black font-semibold">
              I confirm that the above information is correct.
            </p>
          </div>

          <button
            type="submit"
            disabled={isPending}
            className="w-full cursor-pointer py-3 bg-black text-white rounded-lg"
          >
            {isPending ? "creating..." : "Sign Up"}
          </button>

          <div className="flex items-center gap-2 text-sm md:text-[18px]">
            <p>Already have an account?</p>
            <Link className="text-[rgba(50,100,245,0.90)] font-semibold" to="/auth/login">
              Login
            </Link>
          </div>

        </form>
      </FormProvider>
    </>
  );
};

export default UserForm;