import { TiTick } from "react-icons/ti";
import {
  NavLink,
  Outlet,
  ScrollRestoration,
  useLocation,
  useNavigate,
} from "react-router-dom";
import useStep from "../../../Hooks/useStep";
import { useState } from "react";
import { ChevronDown } from "lucide-react";

const Registration = () => {
  const location = useLocation();
  const { step } = useStep();

  const navigate = useNavigate();

  const [open, setOpen] = useState(false);

  const options = [
    {
      label: "As User",
      path: "/register/user",
    },
    {
      label: "As Institute",
      path: "/register/mess",
    },
  ];

  const activeOption =
    options.find((opt) => location.pathname.includes(opt.path)) || options[0];

  const handleSelect = (option) => {
    navigate(option.path);
    setOpen(false);
  };
  return (
    <div className="min-h-screen  flex items-center  w-full font-sans">
      <div
        className={`relative flex flex-row-reverse bg-white 
        ${location?.pathname === "/register/user" ? "h-[850px]" : "h-auto"}
        justify-center items-stretch overflow-hidden  w-full transition-all duration-500`}
      >
        {step !== 3 && step !== 4 && (
          <div className="relative w-full lg:w-1/2 bg-white overflow-hidden hidden md:flex flex-col items-center justify-center px-4 text-black">
            {/* Accent Glow */}
            {/* <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-orange-500/20 to-transparent pointer-events-none"></div> */}

            {/* Floating Image */}
            <div className="relative z-10 w-80 h-80 rounded-full border-[10px] border-white/5 shadow-2xl overflow-hidden transform hover:scale-105 transition-transform duration-700">
              <img
                src="https://i.ibb.co.com/mrn7r0S2/pexels-julieaagaard-2097090-removebg-preview.png"
                alt="Fresh Tomatoes"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="z-10 mt-5 space-y-4 max-w-sm text-center lg:text-left">
              <div className="space-y-4">
                <h2 className="text-4xl font-serif font-bold leading-tight">
                  Fresh meals, <br />
                  <span className="text-orange-400">
                    delivered to your door.
                  </span>
                </h2>

                <div className="space-y-3 pt-4">
                  {[
                    "Delivering Across All Major Cities",
                    "Thousands of Healthy Options",
                    "Trusted by Lakhs of Happy Eaters",
                  ].map((text, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 justify-center lg:justify-start"
                    >
                      <span className="flex-shrink-0 w-5 h-5 rounded-full bg-orange-500 flex items-center justify-center text-[14px] text-white">
                        <TiTick />
                      </span>
                      <p className="text-black text-sm font-medium">{text}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* QR Section */}
              <div className="pt-8 mt-4 border-t border-white/10 flex items-center justify-center lg:justify-start gap-5">
                <div className="p-2 bg-white rounded-2xl">
                  <img
                    src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=sellular-app"
                    alt="QR Code"
                    className="w-14 h-14"
                  />
                </div>
                <div className="text-left">
                  <p className="text-[10px] uppercase tracking-widest text-orange-400 font-black">
                    Get the App
                  </p>
                  <p className="text-sm font-medium text-black">
                    Scan to enjoy exclusive <br />
                    food discounts!
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Left Side: Registration Form */}
        <div
          className={`w-full ${step !== 3 && step !== 4 ? "lg:w-1/2 " : ""}  flex flex-col bg-white`}
        >
          <div className="px-5 pt-8">
            <div className="mb-5 ">
              <span className="text-orange-600 font-bold text-sm tracking-widest uppercase">
                Start for free
              </span>
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mt-2">
                Register
              </h2>
              <p className="mt-4 text-slate-500 leading-relaxed">
                Join the community that celebrates good food and great
                connections.
              </p>
            </div>

            <div className="relative flex items-center justify-center  mb-4">
              {/* Selected */}
              <div
                onClick={() => setOpen(!open)}
                className="flex items-center justify-between bg-slate-100 border border-slate-200 rounded-xl px-4 py-3 cursor-pointer hover:bg-slate-200 transition w-[200px]"
              >
                <span className="font-semibold text-slate-700">
                  {activeOption.label}
                </span>
                <ChevronDown
                  className={`transition-transform duration-300 ${
                    open ? "rotate-180" : ""
                  }`}
                  size={18}
                />
              </div>

              {/* Dropdown */}
              {open && (
                <div className="absolute w-[200px]  bg-white border border-slate-200 top-0 rounded-xl shadow-lg overflow-hidden z-50">
                  {options.map((option) => (
                    <div
                      key={option.path}
                      onClick={() => handleSelect(option)}
                      className={`px-4 py-3 cursor-pointer text-sm font-medium transition 
              ${
                location.pathname === option.path
                  ? "bg-orange-500 text-white"
                  : "hover:bg-slate-100 text-slate-600"
              }`}
                    >
                      {option.label}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Content Area */}
          <div
            className={
              location?.pathname === "/register/user"
                ? "flex-grow px-5 pb-8 overflow-y-auto"
                : "flex-grow px-5  overflow-y-auto"
            }
          >
            <ScrollRestoration />
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Registration;
