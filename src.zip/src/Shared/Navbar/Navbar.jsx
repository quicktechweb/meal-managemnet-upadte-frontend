"use client";

import { useEffect, useState } from "react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div
      className={`w-full z-50 transition-all duration-500
        ${
          scrolled
            ? "fixed top-0 bg-gradient-to-r from-purple-700 to-blue-600 shadow-lg backdrop-blur"
            : "absolute top-0 bg-transparent"
        }
      `}
    >
      <div className="max-w-7xl mx-auto px-10 py-2 flex justify-between items-center text-white">
        {/* LOGO */}
        <div className="text-2xl font-semibold flex items-center">
          <img
            src="https://i.ibb.co/8gMntgXX/Gemini-Generated-Image-m517mjm517mjm7.png"
            alt="Appbeats Logo"
            className="h-20 lg:h-16 object-contain transition-transform duration-300 hover:scale-110"
          />
         
        </div>

        {/* MENU */}
        <ul className="hidden lg:flex gap-8 text-md font-medium opacity-90">
          <li className="hover:opacity-100 cursor-pointer">Home</li>
          <li className="hover:opacity-100 cursor-pointer">Pages</li>
          <li className="hover:opacity-100 cursor-pointer">Features</li>
          <li className="hover:opacity-100 cursor-pointer">Meal</li>
          <li className="hover:opacity-100 cursor-pointer">Ride</li>
          <li className="hover:opacity-100 cursor-pointer">Reviews</li>
          <li className="hover:opacity-100 cursor-pointer">Pricing</li>
          <li className="hover:opacity-100 cursor-pointer">FAQ</li>
          <li className="hover:opacity-100 cursor-pointer">Contact Us</li>
        </ul>
      </div>
    </div>
  );
}
