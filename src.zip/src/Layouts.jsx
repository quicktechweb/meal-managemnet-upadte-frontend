import { Outlet, ScrollRestoration, useLocation } from "react-router-dom";
import Navbar from "./Shared/Navbar/Navbar";
import Footer from "./Shared/Footer/Footer";
import "./index.css";
const Layouts = () => {
  const location = useLocation();

  return (
    <>
      <ScrollRestoration />

      {location.pathname !== "/ecommerce-site" &&
        location.pathname !== "/checkout" && <Navbar />}
      <Outlet />
      {location.pathname !== "/ecommerce-site" &&
        location.pathname !== "/checkout" && <Footer />}
    </>
  );
};

export default Layouts;
