import { useInstituteUserAdminData } from "../../api/cms/user.hook";
import Headline from "../../Components/Headline";
import InstituteMealOnOff from "../../Components/InstituteMealOnOff";
import LiveKitchen from "../../Components/LiveKitchen";
import MealActivity from "../../Components/MealActivity";
import MenuTable from "../../Components/MenuTable";
import PackageMenuRoutine from "../../Components/PackageMenuRoutine";
import useInstituteAuth from "../../Hooks/useInstituteAuth";
import PackageMealActivity from "../FrontEnd/Dashboard/UserDashboard/MealManagementPart/PackageMealActivity";
import InstituteAdminPackageRoutine from "../FrontEnd/institute/admin/InstituteAdminPackageRoutine";
import MealAdminScheduleTable from "../FrontEnd/institute/admin/MealAdminScheduleTable";


const DashboardPage = () => {
  const { user } = useInstituteAuth();

  const { data } = useInstituteUserAdminData(user?.user?.institute_id);

  return (
    <>
      {!data && (
        <div>
          {user?.user?.routine_type === "Routine" && (
            <>
              <div className="mb-2">
                <InstituteMealOnOff />
              </div>
              <MealAdminScheduleTable />
            </>
          )}

          {user?.user?.routine_type === "Package" && (
            <>
              <div className="mb-2">
                <InstituteMealOnOff />
              </div>
              <InstituteAdminPackageRoutine />
            </>
          )}
        </div>
      )}

      {data && (
        <section className="min-h-screen flex flex-col gap-3.5">
          {/* Marquee */}
          <Headline />

          {/* Live Kitchen */}
          <LiveKitchen />

          {/* Menu Table */}
          {data?.routine_type === "Routine" && <MenuTable />}

          {data?.routine_type === "Package" && <PackageMenuRoutine />}

          {/*meal activity  */}

          {data?.routine_type === "Routine" && <MealActivity />}

          {data?.routine_type === "Package" && <PackageMealActivity />}
        </section>
      )}
    </>
  );
};

export default DashboardPage;
