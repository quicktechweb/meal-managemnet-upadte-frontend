import { Link } from "react-router-dom";

const Login = () => {
  return (
    <div className="relative w-screen h-screen bg-white overflow-hidden">
      <img
        src="https://i.ibb.co/whPZTLfk/curve-shape.png"
        alt="Top Gradient"
        className="absolute top-0 left-0 w-full h-[60vh] object-cover z-0"
      />

      <img
        src="https://i.ibb.co/xqXHqXhp/single-round-shape.png"
        alt="big circle"
        className="absolute top-[10%] right-[6%] w-[60vw] max-w-[280px] 2xl:max-w-[380px] z-0 big-circle"
      />

      <img
        src="https://i.ibb.co/YFKRk1D8/round-shape.png"
        alt="small circle"
        className="absolute bottom-[8%] left-[50%] w-[10px] z-10"
      />
      <img
        src="https://i.ibb.co/xqXHqXhp/single-round-shape.png"
        alt="smaller circle"
        className="absolute top-[14%] left-[52%] w-[6px] z-10"
      />

      <img
        src="https://i.ibb.co/ZR7RC2Kq/man-vector.png"
        alt="man"
        className="absolute bottom-[1%] md:top-[30%] md:w-[32vw] left-[16%] w-[22vw] max-w-[360px] z-10 man-image md:max-w-[300px] md:left-[10%] 2xl:left-[25%] 2xl:h-[450px] 2xl:max-w-[400px]
        hidden sm:block"
      />

      <div
        className="absolute top-[22%] right-[14%] w-[90%] md:w-[110%] md:max-w-[400px] sm:w-[28vw] max-w-[420px] 
        bg-white rounded-xl shadow-2xl px-6 sm:px-8 py-10 z-20 login-card left-1/2 
        sm:left-auto transform sm:transform-none -translate-x-1/2 sm:translate-x-0"
      >
        <img
          src="https://i.ibb.co/whPZTLfk/curve-shape.png"
          alt="card top"
          className="absolute top-0 left-0 w-full h-[80px] object-cover rounded-t-xl z-[-1]"
        />

        <img
          src="https://i.ibb.co/YFKRk1D8/round-shape.png"
          alt="small ball"
          className="absolute left-4 top-24 w-6 z-10 "
        />

        <div className="text-center mt-10 mb-6">
          <h2 className="text-2xl font-bold text-black">Login</h2>
          <Link to="/registration"> <p className="text-sm font-semibold">or Create New Account</p>
          </Link>
        </div>

        <div className="mb-4 flex items-center border border-gray-300 rounded-md px-3 py-2 bg-white">
          <img
            src="https://i.ibb.co/YFW6VFRC/user-icon.png"
            alt="user icon"
            className="w-5 h-5 mr-3"
          />
          <input
            type="text"
            placeholder="Your Name"
            defaultValue="01712622555software@gmail.com"
            className="w-full focus:outline-none text-sm"
          />
        </div>

        <div className="mb-4 flex items-center border border-gray-300 rounded-md px-3 py-2 bg-white">
          <img
            src="https://i.ibb.co/SwLdS20x/lock-icon.png"
            alt="lock icon"
            className="w-5 h-5 mr-3"
          />
          <input
            type="password"
            placeholder="Password"
            defaultValue="password123"
            className="w-full focus:outline-none text-sm"
          />
        </div>

        <div className="text-right text-sm font-bold text-black mb-6 cursor-pointer">
          Forgot your Password?
        </div>

        <button className="w-full py-3 text-white font-bold rounded-md bg-gradient-to-r from-red-600 to-black hover:opacity-90">
          Login
        </button>
      </div>
    </div>
  );
};

export default Login;
