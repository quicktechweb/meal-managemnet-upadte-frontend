import { createBrowserRouter } from "react-router-dom";
import Main from "../Layout/Main";
import LoginPage from "../Auth/Login/Login";
import Registration from "../Auth/Registration/Registration";
import Home from "../Pages/FrontEnd/Home/Home/Home";
import Layouts from "../Layouts";
import ErrorPage from "../Shared/ErrorPage/ErrorPage/ErrorPage";


const router = createBrowserRouter([


 {
    path: "/",
    element: <Layouts />,
    errorElement: (
      <>
       <ErrorPage/>
      </>
    ),
    children: [
      
      
      {
    path: "/main",
    element: <Main />,
  },
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/registration",
    element: <Registration />,
  },
 
  
  
  
  
  
 
   
    
     
     
     

        ],
      },

]);

export default router;
