"use client";
import { useState, useEffect } from "react";

const HomeSlider = () => {
  const slides = [
    {
      id: 1,
      bg: "bg-gradient-to-r from-cyan-400 to-blue-300",
      title: "Welcome deal",
      subtitle: "New shopper special",
      imageLeft: "https://i.ibb.co/7rD6Xf0/flipflop.png", // example
      imageRight1: "https://i.ibb.co/cx9G2Pf/offer1.png",
      imageRight2: "https://i.ibb.co/wr6F9CQ/offer2.png",
    },
    {
      id: 2,
      bg: "bg-gradient-to-r from-pink-300 to-red-300",
      title: "Super Sale",
      subtitle: "Up to 70% OFF",
      imageLeft: "https://i.ibb.co/7rD6Xf0/flipflop.png",
      imageRight1: "https://i.ibb.co/cx9G2Pf/offer1.png",
      imageRight2: "https://i.ibb.co/wr6F9CQ/offer2.png",
    },
    {
      id: 3,
      bg: "bg-gradient-to-r from-yellow-300 to-orange-400",
      title: "Flash Deals",
      subtitle: "Limited time offers",
      imageLeft: "https://i.ibb.co/7rD6Xf0/flipflop.png",
      imageRight1: "https://i.ibb.co/cx9G2Pf/offer1.png",
      imageRight2: "https://i.ibb.co/wr6F9CQ/offer2.png",
    },
  ];

  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    }, 4000); // 4 sec auto slide
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className="relative w-full  mx-auto overflow-hidden rounded-md">
      {/* Slides */}
    <div
  className="flex transition-transform duration-700"
  style={{ transform: `translateX(-${current * 100}%)` }}
>
  {slides.map((slide) => (
    <div
      key={slide.id}
      className={`w-full flex-shrink-0 flex items-center justify-between px-10 h-96 ${slide.bg}`} // h-64 → h-80
    >
      {/* Left Image */}
      <div className="flex flex-col items-center">
        <img src={slide.imageLeft} alt="left" className="w-32 h-32" /> {/* image size o baralam */}
        <span className="bg-red-600 text-white text-xs px-2 py-1 rounded-full -mt-6">
          -61%
        </span>
      </div>

      {/* Center Text */}
      <div className="text-center">
        <h2 className="text-3xl font-bold">{slide.title}</h2> {/* bigger text */}
        <p className="text-base text-gray-700">{slide.subtitle}</p>
        <button className="mt-3 bg-black text-white px-6 py-2.5 rounded-md text-sm">
          Shop now
        </button>
      </div>

      {/* Right Images */}
      <div className="flex gap-3">
        <div className="bg-white shadow-md rotate-[-5deg] p-2">
          <img src={slide.imageRight1} alt="offer1" className="w-28 h-28" /> {/* bigger */}
          <span className="text-sm font-semibold">$0.99</span>
        </div>
        <div className="bg-white shadow-md rotate-[5deg] p-2">
          <img src={slide.imageRight2} alt="offer2" className="w-28 h-28" />
          <span className="text-sm font-semibold">$3.00</span>
        </div>
      </div>
    </div>
  ))}
</div>


      {/* Arrows */}
    
     

      {/* Dots */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, index) => (
          <div
            key={index}
            className={`w-8 h-1 rounded-full cursor-pointer ${
              current === index ? "bg-black" : "bg-gray-300"
            }`}
            onClick={() => setCurrent(index)}
          ></div>
        ))}
      </div>
    </div>
  );
};

export default HomeSlider;


  <div className="flex gap-2 px-2 pb-3">
                  <button className="flex-1 bg-[#19745B] text-white text-xs font-semibold py-2 rounded shadow-md hover:opacity-90 transition">
                    Buy Coupon
                  </button>
                  <button className="flex-1 bg-[#19745B] text-white text-xs font-semibold py-2 rounded shadow-md hover:opacity-90 transition">
                    Add to Cart
                  </button>
                </div>