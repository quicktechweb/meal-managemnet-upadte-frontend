import HomeSlider from "../HomeSlider/HomeSlider";
import PremiumProduct from "../PremimumProduct/PremimumProduct";
import ProductCarousel from "../ProductCarousel/ProductCarousel";
import TopRatedProduct from "../TopRatedProduct/TopRatedProduct";
import TopSelling from "../TopSelling/TopSelling";
import CuponPart from "./CuponPart/CuponPart";


const Home = () => {
  return (
    <div>
     <HomeSlider/>
     <TopSelling/>
     <ProductCarousel/>
     <PremiumProduct/>
     <TopRatedProduct/>
     <CuponPart/>
    </div>
  );
};

export default Home;
