import { useState } from "react";
import {
  FaSearch,
  FaShoppingCart,
  FaChevronDown,
  FaQrcode,
} from "react-icons/fa";

const Navbar = () => {
  const [catOpen, setCatOpen] = useState(false);
  const [accOpen, setAccOpen] = useState(false);
  const [appOpen, setAppOpen] = useState(false);

  return (
    <>
      <header className="bg-white border-b">
        <div className="container mx-auto px-6 flex items-center justify-between py-3">
          {/* Left Section: Logo + Categories */}
          <div className="flex items-center gap-6">
            {/* Logo */}
            <img
              className="h-10 w-24"
              src="https://i.ibb.co.com/VY92LX2H/Logo-Lucky-Shop1.png"
              alt="Sellular Logo"
            />

            {/* Categories Dropdown */}
            <div className="relative">
              <button
                onClick={() => setCatOpen(!catOpen)}
                className="flex items-center gap-1 text-md font-medium text-gray-800 hover:text-black focus:outline-none"
              >
                Categories <FaChevronDown className="text-md" />
              </button>

              {catOpen && (
                <div className="absolute left-0 mt-2 w-44 bg-white shadow-lg rounded-md overflow-hidden border border-gray-200 z-50">
                  <ul className="text-sm text-gray-700">
                    <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                      Mobile Phones
                    </li>
                    <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                      Accessories
                    </li>
                    <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                      Wearables
                    </li>
                    <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                      Gaming
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Center Section: Search Bar */}
          <div className="flex-1 mx-8 relative">
            <input
              type="text"
              placeholder="Search our global search engine for products, categories"
              className="w-full border border-gray-300 rounded-full py-2.5 pl-14 pr-4 text-sm text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-black transition"
            />
            {/* Search Icon Circle */}
            <div className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-black rounded-full flex items-center justify-center">
              <FaSearch className="text-white text-sm" />
            </div>
          </div>

          {/* Right Section: Buttons */}
          <div className="flex items-center gap-6 relative">
            {/* Download App Button with QR Hover */}
            <div
              className="relative"
              onMouseEnter={() => setAppOpen(true)}
              onMouseLeave={() => setAppOpen(false)}
            >
              <button className="bg-black text-white text-sm font-semibold py-2 px-5 rounded-md hover:opacity-90 transition flex items-center gap-2">
                <FaQrcode className="text-lg" /> Download Our App
              </button>

              {appOpen && (
                <div className="absolute right-0 mt-2 bg-white shadow-lg rounded-md border border-gray-200 z-50 flex p-4 w-[360px]">
                  {/* Left: QR Code */}
                  <div className="w-28 h-28 border border-gray-300 flex items-center justify-center rounded-md">
                    <img
                      src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=https://play.google.com/store"
                      alt="QR Code"
                      className="w-24 h-24"
                    />
                  </div>

                  {/* Right: Text + Buttons */}
                  <div className="ml-4 flex flex-col justify-between">
                    <div>
                      <p className="text-sm font-semibold text-gray-800">
                        Download the AliExpress app
                      </p>
                      <p className="text-xs text-gray-500">
                        Scan the QR code to download
                      </p>
                    </div>

                    <div className="flex gap-2 mt-3">
                      <a
                        href="https://apps.apple.com/"
                        target="_blank"
                        rel="noreferrer"
                        className="h-10"
                      >
                        <img
                          src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg"
                          alt="App Store"
                          className="h-10"
                        />
                      </a>
                      <a
                        href="https://play.google.com/store"
                        target="_blank"
                        rel="noreferrer"
                        className="h-10"
                      >
                        <img
                          src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                          alt="Google Play"
                          className="h-10"
                        />
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Account Dropdown */}
            <div className="relative">
              <button
                onClick={() => setAccOpen(!accOpen)}
                className="flex items-center gap-1 text-md font-medium text-gray-800 hover:text-black focus:outline-none"
              >
                Account <FaChevronDown className="text-md" />
              </button>

              {accOpen && (
                <div className="absolute right-0 mt-2 w-36 bg-white shadow-lg rounded-md overflow-hidden border border-gray-200 z-50">
                  <ul className="text-sm text-gray-700">
                    <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                      Sign In
                    </li>
                    <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                      Register
                    </li>
                  </ul>
                </div>
              )}
            </div>

            {/* Cart Icon */}
            <div className="relative">
              <FaShoppingCart className="text-xl text-black cursor-pointer" />
              <span className="absolute -top-2 -right-2 bg-black text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">
                0
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* ===== Marquee Text Bar ===== */}
     <div className="bg-gradient-to-r from-black via-gray-900 to-black text-white py-1 overflow-hidden relative shadow-md">
  {/* Scrolling Text Wrapper */}
  <div className="flex whitespace-nowrap animate-marquee">
    <h3 className="text-lg font-semibold tracking-wide px-8">
      🏆 Winner coupon name <span className="text-yellow-400">Tamal Sarkar</span> 🔥
    </h3>
    <h3 className="text-lg font-semibold tracking-wide px-8">
      🎉 Big Offer Coming Soon — <span className="text-green-400">Don’t Miss Out!</span>
    </h3>
    <h3 className="text-lg font-semibold tracking-wide px-8">
      🛒 50% Discount For <span className="text-pink-400">New Users</span> 🚀
    </h3>

    {/* Duplicate for seamless scroll */}
    <h3 className="text-lg font-semibold tracking-wide px-8">
      🏆 Winner coupon name <span className="text-yellow-400">Tamal Sarkar</span> 🔥
    </h3>
    <h3 className="text-lg font-semibold tracking-wide px-8">
      🎉 Big Offer Coming Soon — <span className="text-green-400">Don’t Miss Out!</span>
    </h3>
    <h3 className="text-lg font-semibold tracking-wide px-8">
      🛒 50% Discount For <span className="text-pink-400">New Users</span> 🚀
    </h3>
  </div>

  {/* Animation CSS */}
  <style jsx>{`
    .animate-marquee {
      display: inline-flex;
      animation: marquee 20s linear infinite;
    }
    @keyframes marquee {
      0% {
        transform: translateX(0%);
      }
      100% {
        transform: translateX(-50%);
      }
    }
  `}</style>
</div>

    </>
  );
};

export default Navbar;
